import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suratkeluar',
  templateUrl: './suratkeluar.page.html',
  styleUrls: ['./suratkeluar.page.scss'],
})
export class SuratkeluarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
