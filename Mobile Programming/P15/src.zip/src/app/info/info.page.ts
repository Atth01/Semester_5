// info.page.ts
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Storage } from '@ionic/storage';
import { ApiserviceService } from '../apiservice.service';
import { ToastController, NavController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-info',
  templateUrl: './info.page.html',
  styleUrls: ['./info.page.scss'],
})
export class InfoPage implements OnInit {
  public info!: string;
  isMenuOpen = false;
  infoData: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private storage: Storage,
    private navCtrl: NavController,
    private _apiService: ApiserviceService,
    private toastCtrl: ToastController,
    private alertCtrl: AlertController
  ) {
    this.getInfo();
  }

  ngOnInit() {
    this.info = this.activatedRoute.snapshot.paramMap.get('id') as string;
  }

  async presentToast(msg: any, color: any, icon: any) {
    const toast = await this.toastCtrl.create({
      icon: icon,
      message: msg,
      duration: 1500,
      color: color,
      position: 'top',
    });
    toast.present();
  }

  async getInfo() {
    await this.storage.create();
    this._apiService.getInfo().then((res: any) => {
      if (res.msg == 'ok') {
        this.infoData = res.data;
      } else if (res.msg == 'notFound') {
        this.presentToast(
          'Belum ada info !',
          'warning',
          'alert-circle-outline'
        );
      } else if (res.msg == 'err') {
        this.presentToast(
          'Something went wrong',
          'danger',
          'alert-circle-outline'
        );
      }
    });
  }

  handleRefresh(event: any) {
    setTimeout(() => {
      this.getInfo();
      event.target.complete();
    }, 2000);
  }

  edit(kd_info: string) {
    console.log('kd_info:', kd_info);
    
    if (kd_info && kd_info.trim() !== '') {
      this.navCtrl.navigateRoot('/updateinfo?kd_info=' + kd_info);
    } else {
      this.presentToast('Invalid kd_info value', 'danger', 'alert-circle-outline');
    }
  }

  async confirmDelete(kd_info: string) {
    const alert = await this.alertCtrl.create({
      header: 'Confirm Delete',
      message: 'Are you sure you want to delete this information?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (cancel) => {
            console.log('Delete canceled');
          },
        },
        {
          text: 'Delete',
          handler: () => {
            this.deleteInfo(kd_info);
          },
        },
      ],
    });

    await alert.present();
  }

  async deleteInfo(kd: string) {
    try {
      const res = await this._apiService.deleteInfo(kd);

      if (res.msg === 'ok') {
        this.presentToast('Data berhasil dihapus!', 'success', 'checkmark-circle-outline');
        this.getInfo(); // Refresh data setelah penghapusan
      } else if (res.msg === 'notOk') {
        this.presentToast('Data gagal dihapus!', 'danger', 'alert-circle-outline');
      } else {
        this.presentToast('Something went wrong!', 'danger', 'alert-circle-outline');
      }
    } catch (err: any) {
      this.presentToast('Error: ' + err.err, 'danger', 'alert-circle-outline');
    }
  }
}
