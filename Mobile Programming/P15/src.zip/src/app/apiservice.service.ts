import { Injectable } from '@angular/core';
import axios, { AxiosResponse, AxiosError } from 'axios'; // Import AxiosResponse dan AxiosError

@Injectable({
  providedIn: 'root',
})
export class ApiserviceService {
  public uriApi: string = 'https://greenland-foresthill.id/rest-api/index.php/';

  constructor() { }
  // Penduduk
  async getPenduduk(nik: string) {
    try {
      var url = '';
      if (
        nik == undefined || nik == ''
      ) {
        url = this.uriApi + 'penduduk';
        const res: AxiosResponse = await axios.get(url);
        console.log(res)
        let data = res.data.result;
        return {
          msg: 'ok',
          data: data,
        };
      } else {
        url = this.uriApi + 'penduduk?kd_pnddk=' + nik;
        const res: AxiosResponse = await axios.get(url);
        let data = res.data.result;
        return {
          msg: 'ok',
          data: data[0],
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async createPenduduk(data: any) {
    try {
      let url = this.uriApi + 'penduduk';

      const res = await axios.post(url, data);
      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      console.log(err);
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async update_Penduduk(data: any) {
    try {
      let url = this.uriApi + 'update_penduduk'; // Ensure this matches your server-side endpoint
      const res: AxiosResponse = await axios.post(url, data);
      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async deletePenduduk(kd: string) {
    try {
      let url = this.uriApi + 'delete_penduduk';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }


  // Info
  async getInfo() {
    try {
      let url = this.uriApi + 'info';
      const res: AxiosResponse = await axios.get(url); // Tentukan tipe AxiosResponse
      let data = res.data.result;
      console.log(data)
      return {
        msg: 'ok',
        data: data,
      };
    } catch (err: any) {
      console.log(err);
      if (axios.isAxiosError(err) && err.response && err.response.data && err.response.data.status == 'Err') {
        return {
          msg: 'notFound',
        };
      } else {
        return {
          msg: 'err',
          err: err,
        };
      }
    }
  }
  async createInfo(data: any) {
    try {
      let url = this.uriApi + 'info';

      const res = await axios.post(url, data);

      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      console.log(err);
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async updateInfo(data: any, kd: string) {
    try {
      let url = this.uriApi + 'update_info';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
        judul_info: data.judul_info,
        informasi: data.informasi,
        tgl_info: data.tgl_info,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async deleteInfo(kd: string) {
    try {
      let url = this.uriApi + 'delete_info';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }


  // Blok
  async getBlok() {
    try {
      let url = this.uriApi + 'blok';
      // if (kd) {
      //     url += `?kd=${kd}`;
      // }

      const res: AxiosResponse = await axios.get(url);

      let data = res.data.result;
      return {
        msg: 'ok',
        data: data,
      };
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async createBlok(data: any) {
    try {
      let url = this.uriApi + 'blok_kavling';

      const res = await axios.post(url, data);

      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      console.log(err);
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async updateBlok(data: any, kd: string) {
    try {
      let url = this.uriApi + 'update_blok';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
        nama_blok: data.nama_blok,
        no_blok: data.no_blok,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }

  async deleteBlok(kd: string) {
    try {
      let url = this.uriApi + 'delete_blok';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }

  // Iuran
  async getIuran() {
    try {
      let url = this.uriApi + 'iuran';

      // // Build query parameters based on provided values
      // const queryParams: string[] = [];
      // if (kd) queryParams.push(`kd=${kd}`);
      // if (tahun) queryParams.push(`thn=${tahun}`);
      // if (bulan) queryParams.push(`bln=${bulan}`);
      // if (jenis) queryParams.push(`jenis=${jenis}`);

      // // Append query parameters to the URL
      // if (queryParams.length > 0) {
      //     url += '?' + queryParams.join('&');
      // }

      const res: AxiosResponse = await axios.get(url);

      let data = res.data.result;
      return {
        msg: 'ok',
        data: data,
      };
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async createIuran(data: any) {
    try {
      let url = this.uriApi + 'iuran';

      const res = await axios.post(url, data);

      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      console.log(err);
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async updateIuran(data: any, kd: string) {
    try {
      let url = this.uriApi + 'update_iuran';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
        status: data.status,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async deleteIuran(kd: string) {
    try {
      let url = this.uriApi + 'delete_iuran';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }

  // Pesan
  async getPesan() {
    try {
      let url = this.uriApi + 'get_pesan';

      const res: AxiosResponse = await axios.get(url);

      let data = res.data.result;
      return {
        msg: 'ok',
        data: data,
      };
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }

  async createPesan(data: any) {
    try {
      let url = this.uriApi + 'pesan';

      const res = await axios.post(url, data);

      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      console.log(err);
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async updatePesan(data: any, nik: string) {
    try {
      let url = this.uriApi + 'update_pesan';
      const res: AxiosResponse = await axios.post(url, {
        nik: nik,
        status: data.status,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async deletePesan(nik: string) {
    try {
      let url = this.uriApi + 'delete_pesan';
      const res: AxiosResponse = await axios.post(url, {
        nik: nik,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }

  // Surat
  async getSurat(nik: string) {
    try {
      var url = '';
      if (
        nik == ''
      ) {
        url = this.uriApi + 'surat';
      } else {
        url = this.uriApi + 'surat?nik=' + nik;
      }

      const res: AxiosResponse = await axios.get(url);

      let data = res.data.result;
      return {
        msg: 'ok',
        data: data,
      };
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async createSurat(data: any) {
    try {
      let url = this.uriApi + 'surat';

      const res = await axios.post(url, data);
      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      console.log(err);
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async updateSurat(data: any) {
    try {
      let url = this.uriApi + 'index_post'; // Ensure this matches your server-side endpoint
      const res: AxiosResponse = await axios.post(url, {
        kd: data.kd,
        status_huni: data.status_huni,
      });
      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async deleteSurat(kd: string) {
    try {
      let url = this.uriApi + 'delete_surat';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }

  // User
  async getUser(nik: string) {
    try {
      var url = '';
      if (
        nik == ''
      ) {
        url = this.uriApi + 'user';
      } else {
        url = this.uriApi + 'user?nik=' + nik;
      }

      const res: AxiosResponse = await axios.get(url);

      let data = res.data.result;
      return {
        msg: 'ok',
        data: data,
      };
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async createUser(data: any) {
    try {
      let url = this.uriApi + 'user';

      const res = await axios.post(url, data);
      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      console.log(err);
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async updateUser(data: any) {
    try {
      let url = this.uriApi + 'index_post'; // Ensure this matches your server-side endpoint
      const res: AxiosResponse = await axios.post(url, {
        kd: data.kd,
        status_huni: data.status_huni,
      });
      if (res.data.status == 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
  async deleteUser(kd: string) {
    try {
      let url = this.uriApi + 'delete_user';
      const res: AxiosResponse = await axios.post(url, {
        kd: kd,
      });

      if (res.data.status === 'Ok') {
        return {
          msg: 'ok',
        };
      } else {
        return {
          msg: 'notOk',
        };
      }
    } catch (err: any) {
      return {
        msg: 'err',
        err: err,
      };
    }
  }
}

