import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  AlertController,
  LoadingController,
  NavController,
  ToastController,
  ModalController,
} from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { ApiserviceService } from '../apiservice.service';

@Component({
  selector: 'app-updateinfo',
  templateUrl: './updateinfo.page.html',
  styleUrls: ['./updateinfo.page.scss'],
})
export class UpdateinfoPage implements OnInit {
  public Data: any;
  public kd_info: any;
  public judul_info: string = '';
  public informasi: string = '';
  public tgl_info: string = '';

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private navCtrl: NavController,
    private storage: Storage,
    private _apiService: ApiserviceService
  ) { 
    this.route.queryParams.subscribe((params) => {
      const kd_info = params['kd_info'];
      if (kd_info == null) {
        this.presentToast(
          'No Parameter found!',
          'warning',
          'alert-circle-outline'
        );
      } else {
        this.getInfo(kd_info);
      }
    });
  }

  async presentToast(msg: any, color: any, icon: any) {
    const toast = await this.toastCtrl.create({
      icon: icon,
      message: msg,
      duration: 1500,
      color: color,
      position: 'top',
    });
    toast.present();
  }

  async getInfo(kd_info: string) {
    await this.storage.create();
    this._apiService.getInfo().then((res) => {
      if (res.msg == 'ok') {
        console.log(res.data);
        this.Data = Array(res.data);
        if (res.data !== null) {
          this.kd_info = res.data.kd_info;
          this.judul_info = res.data.judul_info;
          this.informasi = res.data.tgl_info;
        }
      } else if (res.msg == 'err') {
        this.presentToast(
          'Something went wrong',
          'danger',
          'alert-circle-outline'
        );
      }
    });
  }

  async Update() {
    if (
      this.kd_info == '' &&
      this.judul_info == '' &&
      this.informasi == '' &&
      this.tgl_info == ''
    ) {
      this.presentToast(
        'Tidak boleh ada form yang kosong, harap isi semua form!',
        'warning',
        'alert-circle-outline'
      );
    } else {
      const loader = await this.loadingCtrl.create({
        message: 'Please wait...',
        spinner: 'lines',
      });
      loader.present();
      const formData = new FormData();
      formData.append('kd_info', this.kd_info);
      formData.append('judul_info', this.judul_info);
      formData.append('informasi', this.informasi);
      formData.append('tgl_info', this.tgl_info);
      this._apiService.updateInfo(formData, this.kd_info).then((res) => {
        if (res.msg == 'ok') {
          this.loadingCtrl.dismiss();
          this.presentToast(
            'Data berhasil diubah !',
            'success',
            'checkmark-circle-outline'
          );
          this.navCtrl.navigateRoot('/info');
        } else if (res.msg == 'notOk') {
          this.loadingCtrl.dismiss();
          this.presentToast(
            'Data gagal diubah !',
            'danger',
            'alert-circle-outline'
          );
        } else if (res.msg == 'err') {
          this.loadingCtrl.dismiss();
          this.presentToast(
            'Something went wrong !',
            'danger',
            'alert-circle-outline'
          );
        }
      });
    }
  }
  Back() {
    // Ganti 'info' dengan path yang sesuai untuk halaman info Anda
    this.navCtrl.navigateForward('/info');
  }

  ngOnInit() {
  }
}
