import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addpenduduk',
  templateUrl: './addpenduduk.page.html',
  styleUrls: ['./addpenduduk.page.scss'],
})
export class AddpendudukPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
