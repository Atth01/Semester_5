import { Component, OnInit } from '@angular/core';
import { ToastController, NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { ApiserviceService } from '../apiservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.page.html',
  styleUrls: ['./user.page.scss'],
})
export class UserPage implements OnInit {
  public Data: any;
  isReadOnly = false; // Menentukan properti isReadOnly

  public user: string = '';

  constructor(
    private toastCtrl: ToastController,
    private navCtrl: NavController,
    private storage: Storage,
    private _apiService: ApiserviceService,
    private router: Router
  ) { 
    this.getUser();
  }
  async presentToast(msg: any, color: any, icon: any) {
    const toast = await this.toastCtrl.create({
      icon: icon,
      message: msg,
      duration: 1500,
      color: color,
      position: 'top',
    });
    toast.present();
  }
  async getUser() {
    await this.storage.create();
    // Berikan nilai val sesuai kebutuhan
    
    this._apiService.getUser('').then((res: any) => {
      if (res.msg == 'ok') {
        this.Data = res.data;
        this.user = String(res.data[0].user);
      } else if (res.msg == 'err') {
        this.presentToast(
          'Terjadi kesalahan: ' + String(res.err),
          'danger',
          'alert-circle-outline'
        );
      }
    });
  }
  handleRefresh(event: any) {
    setTimeout(() => {
      this.getUser();
      event.target.complete();
    }, 2000);
  }

  ngOnInit() {
  }

}
