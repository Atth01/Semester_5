import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  AlertController,
  LoadingController,
  NavController,
  ToastController,
  ModalController,
} from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { ApiserviceService } from '../apiservice.service';

@Component({
  selector: 'app-updateiuran',
  templateUrl: './updateiuran.page.html',
  styleUrls: ['./updateiuran.page.scss'],
})
export class UpdateiuranPage implements OnInit {

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private navCtrl: NavController,
    private storage: Storage,
    private _apiService: ApiserviceService
  ) { }

  ngOnInit() {
  }
  back(){
    this.navCtrl.navigateRoot('/iuran');
  }

}
