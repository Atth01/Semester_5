import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatesurat',
  templateUrl: './updatesurat.page.html',
  styleUrls: ['./updatesurat.page.scss'],
})
export class UpdatesuratPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
