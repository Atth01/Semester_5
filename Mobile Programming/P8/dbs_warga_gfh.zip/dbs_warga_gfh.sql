-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Oct 31, 2023 at 09:57 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs_warga_gfh`
--

-- --------------------------------------------------------

--
-- Table structure for table `blok_kavling`
--

CREATE TABLE `blok_kavling` (
  `kd_blok` int(5) NOT NULL,
  `nama_blok` varchar(3) NOT NULL,
  `no_blok` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blok_kavling`
--

INSERT INTO `blok_kavling` (`kd_blok`, `nama_blok`, `no_blok`) VALUES
(1, 'E1', '02'),
(2, 'E1', '07'),
(3, 'E1', '08'),
(4, 'E1', '09'),
(5, 'E1', '10'),
(6, 'E1', '12'),
(7, 'E1', '12A'),
(8, 'E2', '01'),
(9, 'E2', '02'),
(10, 'E2', '03');

-- --------------------------------------------------------

--
-- Table structure for table `info_warga`
--

CREATE TABLE `info_warga` (
  `kd_info` int(11) NOT NULL,
  `judul_info` varchar(30) NOT NULL,
  `informasi` text NOT NULL,
  `tgl_info` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iuran_warga`
--

CREATE TABLE `iuran_warga` (
  `kd_iuran` int(11) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `jenis_pembayaran` enum('KAS','Lainnya') NOT NULL,
  `keterangan` text NOT NULL,
  `tgl_pembayaran` date NOT NULL,
  `bukti_iuran` varchar(100) NOT NULL,
  `kas_tahun` varchar(4) NOT NULL,
  `kas_bulan` int(1) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `penduduk`
--

CREATE TABLE `penduduk` (
  `kd_penduduk` int(11) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `kk` varchar(16) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tempat_lahir` varchar(30) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `agama` enum('Islam','Kristen','Budha','Hindu','Konghucu') NOT NULL,
  `status_perkawinan` enum('Menikah','Belum Menikah','Janda','Duda') NOT NULL,
  `status_keluarga` enum('Kepala Keluarga','Istri','Anak','Orang Tua','Saudara') NOT NULL,
  `status_pekerjaan` enum('PNS','Karyawan Swasta','Dosen','Guru','Wiraswasta','Mengurus Rumah Tangga','Pelajar/Mahasiswa') NOT NULL,
  `status_kewarganegaraan` enum('WNI','WNA') NOT NULL,
  `kd_blok` int(5) NOT NULL,
  `status_kavling` enum('Pemilik','Kontrak') NOT NULL,
  `tgl_masuk` date NOT NULL,
  `status_huni` enum('Aktif','Tidak Aktif') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pesan_warga`
--

CREATE TABLE `pesan_warga` (
  `kd_pesan` int(11) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `pesan` text NOT NULL,
  `tgl_pesan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blok_kavling`
--
ALTER TABLE `blok_kavling`
  ADD PRIMARY KEY (`kd_blok`);

--
-- Indexes for table `info_warga`
--
ALTER TABLE `info_warga`
  ADD PRIMARY KEY (`kd_info`);

--
-- Indexes for table `iuran_warga`
--
ALTER TABLE `iuran_warga`
  ADD PRIMARY KEY (`kd_iuran`);

--
-- Indexes for table `penduduk`
--
ALTER TABLE `penduduk`
  ADD PRIMARY KEY (`kd_penduduk`),
  ADD UNIQUE KEY `nik` (`nik`);

--
-- Indexes for table `pesan_warga`
--
ALTER TABLE `pesan_warga`
  ADD PRIMARY KEY (`kd_pesan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blok_kavling`
--
ALTER TABLE `blok_kavling`
  MODIFY `kd_blok` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `info_warga`
--
ALTER TABLE `info_warga`
  MODIFY `kd_info` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `iuran_warga`
--
ALTER TABLE `iuran_warga`
  MODIFY `kd_iuran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `penduduk`
--
ALTER TABLE `penduduk`
  MODIFY `kd_penduduk` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pesan_warga`
--
ALTER TABLE `pesan_warga`
  MODIFY `kd_pesan` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
